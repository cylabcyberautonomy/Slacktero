# slack-zotero-bot

Mention the bot with a link in Slack; it extracts the metadata and adds the
item to your Zotero group library (unfiled) if it isn't already there.

```
@biblio-bot https://arxiv.org/abs/2604.11978
  └─ "Added to the group library: HORIZON: ..."
```

## How it works

Two containers via `docker-compose`:

- **bot** — a Slack Bolt app running in Socket Mode (no public endpoint).
  On `app_mention` it parses the URL, calls the translation-server, checks the
  group for a duplicate, and writes the item.
- **translation-server** — Zotero's own translator engine. Turns a URL into
  Zotero-format item JSON, which the bot writes straight to the Web API.

It's stateless: deduplication queries the Zotero library itself, so there's no
database or volume.

## Prerequisites

You'll need three things set up before first run.

### 1. A Slack app (Socket Mode)

At <https://api.slack.com/apps> → Create New App → From scratch, then:

- **Socket Mode** → enable it. This generates an **App-Level Token**
  (`xapp-…`) with the `connections:write` scope → `SLACK_APP_TOKEN`.
- **OAuth & Permissions** → Bot Token Scopes → add `app_mentions:read` and
  `chat:write`. Install to the workspace → copy the **Bot User OAuth Token**
  (`xoxb-…`) → `SLACK_BOT_TOKEN`.
- **Event Subscriptions** → enable → Subscribe to bot events → add
  `app_mention`.
- Invite the bot into the target channel: `/invite @your-bot`.

### 2. A Zotero API key + group ID

- API key: <https://www.zotero.org/settings/keys> → create a key with
  **write** access to the group → `ZOTERO_API_KEY`.
- Group ID: the **numeric** ID of the group (visible on the API Keys page and
  in group URLs), not the group name → `ZOTERO_GROUP_ID`.

### 3. Docker

Docker Engine + Compose v2 (`docker compose`).

## Run

```bash
cp .env.example .env      # then fill in the four values
docker compose up --build
```

Mention the bot with a link in a channel it's in. Replies land in a thread.

## Architecture note: translation-server image

The official `zotero/translation-server` image's `latest` tag is **arm64**.

- On Apple Silicon / arm64 hosts: the default `image: zotero/translation-server`
  works as-is.
- On x86 hosts: if the pull fails with a manifest error, either pin the amd64
  build in `docker-compose.yml`:

  ```yaml
  image: zotero/translation-server:2.0.4
  ```

  (older translators, but runs natively) **or** build from source for current
  translators on any arch:

  ```bash
  git clone --recurse-submodules https://github.com/zotero/translation-server
  cd translation-server && docker build -t translation-server-local .
  ```

  then set `image: translation-server-local` in the compose file.

## Known limitation: URL-only dedup

Deduplication is authoritative when the item has a **DOI** — the bot searches
the group for it and skips a match. For items without a DOI (blog posts, news,
some preprint landing pages), the Web API has no exact-URL filter, so the bot
falls back to a best-effort quicksearch that can miss near-duplicates.

If that becomes a problem, the upgrade is a small persistent index
(`normalized_url → itemKey`) written on each successful add — at the cost of
adding the stateful component this design currently avoids. For a DOI-heavy
research bibliography it likely won't be needed.

## Files

```
slack-zotero-bot/
├── docker-compose.yml      # bot + translation-server
├── .env.example            # copy to .env
└── bot/
    ├── Dockerfile
    ├── requirements.txt
    ├── app.py              # Slack handler + orchestration
    └── zotero.py           # translate(), find_existing(), add_item()
```
